from flask import Flask, request, render_template
import requests
import uuid
import time
import json
import urllib.parse


app = Flask(__name__)
app.static_folder = 'templates'

# OCR API 정보
ocr_api_url = 'https://ivk4cjfga5.apigw.ntruss.com/custom/v1/24175/f04958d613cf535a44829e0234762ccb2f042df5cd34c326bf9fd7839abfe7a5/general'
ocr_secret_key = 'WEJTdEtEZ0ZwQ21LTmhIemRLSEhNenVsZ2Jpc1NhYmg='

# Papago 번역 API 정보
client_id = "JoN6cwtfdXQXEhzoPCY2"  # 개발자센터에서 발급받은 Client ID 값
client_secret = "6wT2ekTTgg"  # 개발자센터에서 발급받은 Client Secret 값

@app.route('/')
def index():
    return render_template('index.html', text=None, translated_text=None)

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return "파일이 없습니다."

    image_file = request.files['file']

    ocr_request_json = {
        'images': [
            {
                'format': 'jpg',
                'name': 'demo'
            }
        ],
        'requestId': str(uuid.uuid4()),
        'version': 'V2',
        'timestamp': int(round(time.time() * 1000))
    }

    ocr_payload = {'message': json.dumps(ocr_request_json).encode('UTF-8')}
    ocr_files = [('file', image_file)]
    ocr_headers = {
        'X-OCR-SECRET': ocr_secret_key
    }

    ocr_response = requests.request("POST", ocr_api_url, headers=ocr_headers, data=ocr_payload, files=ocr_files)
    ocr_result = ocr_response.json()

    extracted_text = ""
    for field in ocr_result['images'][0]['fields']:
        extracted_text += field['inferText']

    return render_template('index.html', text=extracted_text, summarized_text=None)


@app.route('/translate', methods=['POST'])
def translate_text():
    text_to_translate = request.form['text_to_translate']
    
    # 한국어와 영어의 비율 계산
    korean_count = sum(c in '가-힣' for c in text_to_translate)
    english_count = sum(c in 'a-zA-Z' for c in text_to_translate)
    
    if korean_count >= english_count:
        source_lang = 'ko'
        target_lang = 'en'
    else:
        source_lang = 'en'
        target_lang = 'ko'
    
    encText = urllib.parse.quote(text_to_translate)
    data = "source={}&target={}&text=".format(source_lang, target_lang) + encText

    translation_url = "https://openapi.naver.com/v1/papago/n2mt"
    translation_request = urllib.request.Request(translation_url)
    translation_request.add_header("X-Naver-Client-Id", client_id)
    translation_request.add_header("X-Naver-Client-Secret", client_secret)

    response = urllib.request.urlopen(translation_request, data=data.encode("utf-8"))
    rescode = response.getcode()

    if rescode == 200:
        response_body = response.read()
        translated_text = json.loads(response_body.decode('utf-8'))['message']['result']['translatedText']
    else:
        translated_text = "번역에 실패했습니다."

    return render_template('index.html', text=text_to_translate, translated_text=translated_text)

if __name__ == '__main__':
    app.run(host = '172.30.129.1')
    app.run(host = '0.0.0.0', debug = True)